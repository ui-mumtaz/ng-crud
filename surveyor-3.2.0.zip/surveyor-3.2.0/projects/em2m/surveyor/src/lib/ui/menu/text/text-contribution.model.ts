export interface TextMenuContributionConfig {
  text: string;
  classes?: string;
}
