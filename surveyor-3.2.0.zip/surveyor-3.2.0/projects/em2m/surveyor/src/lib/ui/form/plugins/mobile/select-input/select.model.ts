export interface SelectOptions {
  selections: SelectOptionsSelection[];
}

export interface SelectOptionsSelection {
  value: any;
  label: string;
}
