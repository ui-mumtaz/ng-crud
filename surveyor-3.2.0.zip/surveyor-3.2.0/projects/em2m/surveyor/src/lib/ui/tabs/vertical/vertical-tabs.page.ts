import {Component} from '@angular/core';

@Component({
  template: '<vertical-tabs [contentGridWidth]="8" class="flex-horizontal"></vertical-tabs>',
})
export class VerticalTabsPage {

  constructor() {}
}
