import {Component} from '@angular/core';

@Component({
  template: '<div class="flex-vertical"><surveyor-bottom-tabs></surveyor-bottom-tabs></div>'
})
export class BottomTabsPage {

  constructor() {
  }
}
