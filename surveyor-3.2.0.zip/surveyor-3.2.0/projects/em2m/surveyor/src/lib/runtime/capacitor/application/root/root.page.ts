import {Component} from '@angular/core';

@Component({
  templateUrl: './root.page.html'
})
export class CapacitorRootPage {

  constructor() {}
}
