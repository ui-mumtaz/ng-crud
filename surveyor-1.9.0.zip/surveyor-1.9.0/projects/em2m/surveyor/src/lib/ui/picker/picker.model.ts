import {ModalOptions} from "../modal/modal.model";

export interface PickerOptions extends ModalOptions {
}
