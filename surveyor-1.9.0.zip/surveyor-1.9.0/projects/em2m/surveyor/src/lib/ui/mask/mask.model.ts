export class MaskedValue {
  modelValue: string;
  viewValue: string;
}
