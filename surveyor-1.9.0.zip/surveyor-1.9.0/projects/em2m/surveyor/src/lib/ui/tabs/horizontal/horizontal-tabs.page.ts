import {Component} from "@angular/core";

@Component({
  template: "<horizontal-tabs></horizontal-tabs>",
})
export class HorizontalTabsPage {

  constructor() {
  }
}
