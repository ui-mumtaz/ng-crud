
export interface BreadcrumbItem {
  label: string;
  href?: string;
  items?: Array<BreadcrumbItem>;
}
