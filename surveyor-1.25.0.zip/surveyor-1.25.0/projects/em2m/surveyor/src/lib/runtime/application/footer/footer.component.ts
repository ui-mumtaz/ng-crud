import {Component} from '@angular/core';

@Component({
  selector: 'surveyor-application-footer',
  templateUrl: './footer.component.html'
})
export class ApplicationFooterComponent {

  constructor() {}
}
